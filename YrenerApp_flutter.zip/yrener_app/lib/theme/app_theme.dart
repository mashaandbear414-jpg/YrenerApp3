import 'package:flutter/material.dart';

class AppTheme {
  static const Color accent = Color(0xFFE63E3E);
  static const Color accent2 = Color(0xFFFF5555);

  // 0 = Чёрная, 1 = Белая, 2 = Своя (тёмно-красная)
  static ThemeData getTheme(int index) {
    switch (index) {
      case 1: return _whiteTheme();
      case 2: return _customTheme();
      default: return _blackTheme();
    }
  }

  static ThemeData _blackTheme() => ThemeData(
    brightness: Brightness.dark,
    scaffoldBackgroundColor: const Color(0xFF0A0A0A),
    colorScheme: const ColorScheme.dark(
      primary: accent,
      surface: Color(0xFF111111),
    ),
    cardColor: const Color(0xFF111111),
    fontFamily: 'Inter',
  );

  static ThemeData _whiteTheme() => ThemeData(
    brightness: Brightness.light,
    scaffoldBackgroundColor: const Color(0xFFF5F5F5),
    colorScheme: const ColorScheme.light(
      primary: accent,
      surface: Colors.white,
    ),
    cardColor: Colors.white,
    fontFamily: 'Inter',
  );

  static ThemeData _customTheme() => ThemeData(
    brightness: Brightness.dark,
    scaffoldBackgroundColor: const Color(0xFF1A0A0A),
    colorScheme: const ColorScheme.dark(
      primary: accent,
      surface: Color(0xFF2A0F0F),
    ),
    cardColor: const Color(0xFF2A0F0F),
    fontFamily: 'Inter',
  );
}
