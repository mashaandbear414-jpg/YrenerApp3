import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  // Замени на свой ngrok/IP адрес сервера
  static const String baseUrl = 'https://YOUR_SERVER_URL';
  static const String botToken = '8601640788:AAFmh2jGX3VrP_jVuiKnfjXE7BH6wZNetgQ';

  // Проверка ключа через бота
  static Future<Map<String, dynamic>> checkKey(String key) async {
    try {
      final uri = Uri.parse('$baseUrl/check_key?key=${Uri.encodeComponent(key)}');
      final res = await http.get(uri).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        return jsonDecode(res.body);
      }
    } catch (e) {
      return {'valid': false, 'error': e.toString()};
    }
    return {'valid': false};
  }

  // Сохранить данные пользователя
  static Future<void> saveUser(String email, String name, String key) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('user_email', email);
    await prefs.setString('user_name', name);
    await prefs.setString('user_key', key);
    await prefs.setInt('key_saved_at', DateTime.now().millisecondsSinceEpoch);
  }

  static Future<Map<String, String?>> getSavedUser() async {
    final prefs = await SharedPreferences.getInstance();
    return {
      'email': prefs.getString('user_email'),
      'name': prefs.getString('user_name'),
      'key': prefs.getString('user_key'),
    };
  }

  static Future<void> clearUser() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('user_email');
    await prefs.remove('user_name');
    await prefs.remove('user_key');
    await prefs.remove('key_saved_at');
  }
}
