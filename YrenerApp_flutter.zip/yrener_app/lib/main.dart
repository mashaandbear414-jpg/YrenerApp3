import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'screens/splash_screen.dart';
import 'theme/app_theme.dart';
import 'l10n/app_localizations.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));
  final prefs = await SharedPreferences.getInstance();
  final themeIndex = prefs.getInt('theme') ?? 0;
  final langCode = prefs.getString('lang') ?? 'ru';
  runApp(YrenerApp(themeIndex: themeIndex, langCode: langCode));
}

class YrenerApp extends StatefulWidget {
  final int themeIndex;
  final String langCode;
  const YrenerApp({super.key, required this.themeIndex, required this.langCode});

  static _YrenerAppState? of(BuildContext context) =>
      context.findAncestorStateOfType<_YrenerAppState>();

  @override
  State<YrenerApp> createState() => _YrenerAppState();
}

class _YrenerAppState extends State<YrenerApp> {
  late int _themeIndex;
  late Locale _locale;

  @override
  void initState() {
    super.initState();
    _themeIndex = widget.themeIndex;
    _locale = Locale(widget.langCode);
  }

  void setTheme(int index) async {
    setState(() => _themeIndex = index);
    final prefs = await SharedPreferences.getInstance();
    prefs.setInt('theme', index);
  }

  void setLocale(String langCode) async {
    setState(() => _locale = Locale(langCode));
    final prefs = await SharedPreferences.getInstance();
    prefs.setString('lang', langCode);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Yrener',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.getTheme(_themeIndex),
      locale: _locale,
      supportedLocales: const [
        Locale('ru'), Locale('uk'), Locale('en'), Locale('zh'),
      ],
      localizationsDelegates: AppLocalizations.localizationsDelegates,
      home: const SplashScreen(),
    );
  }
}
