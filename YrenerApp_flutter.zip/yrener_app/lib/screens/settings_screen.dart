import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../main.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  int _themeIndex = 0;
  String _langCode = 'ru';

  final _languages = [
    {'code': 'ru', 'label': '🇷🇺 Русский'},
    {'code': 'uk', 'label': '🇺🇦 Українська'},
    {'code': 'en', 'label': '🇬🇧 English'},
    {'code': 'zh', 'label': '🇨🇳 中文'},
  ];

  final _themes = [
    {'label': 'Чёрная', 'icon': Icons.dark_mode},
    {'label': 'Белая', 'icon': Icons.light_mode},
    {'label': 'На твой вкус', 'icon': Icons.palette},
  ];

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = isDark ? Colors.white : const Color(0xFF1A1A1A);
    final muted = isDark ? const Color(0xFF666666) : const Color(0xFF999999);
    final card = isDark ? const Color(0xFF111111) : Colors.white;
    final border = isDark ? Colors.white.withOpacity(0.07) : Colors.black.withOpacity(0.07);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        title: Text('Настройки', style: TextStyle(
            color: textColor, fontWeight: FontWeight.w800)),
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: textColor),
          onPressed: () => Navigator.pop(context),
        ),
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          // Язык
          Text('ЯЗЫК', style: TextStyle(
            fontSize: 11, color: muted, fontWeight: FontWeight.w600,
            letterSpacing: 1.5,
          )),
          const SizedBox(height: 10),
          Container(
            decoration: BoxDecoration(
              color: card,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: border),
            ),
            child: Column(
              children: _languages.asMap().entries.map((e) {
                final lang = e.value;
                final isLast = e.key == _languages.length - 1;
                final selected = _langCode == lang['code'];
                return GestureDetector(
                  onTap: () {
                    setState(() => _langCode = lang['code']!);
                    YrenerApp.of(context)?.setLocale(lang['code']!);
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
                    decoration: BoxDecoration(
                      border: isLast ? null : Border(
                          bottom: BorderSide(color: border)),
                    ),
                    child: Row(
                      children: [
                        Text(lang['label']!, style: TextStyle(
                            color: textColor, fontSize: 15)),
                        const Spacer(),
                        if (selected)
                          const Icon(Icons.check_circle,
                              color: AppTheme.accent, size: 20),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
          ),

          const SizedBox(height: 28),

          // Тема
          Text('ИНТЕРФЕЙС', style: TextStyle(
            fontSize: 11, color: muted, fontWeight: FontWeight.w600,
            letterSpacing: 1.5,
          )),
          const SizedBox(height: 10),
          Row(
            children: _themes.asMap().entries.map((e) {
              final i = e.key;
              final t = e.value;
              final selected = _themeIndex == i;
              return Expanded(
                child: Padding(
                  padding: EdgeInsets.only(right: i < 2 ? 10 : 0),
                  child: GestureDetector(
                    onTap: () {
                      setState(() => _themeIndex = i);
                      YrenerApp.of(context)?.setTheme(i);
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      decoration: BoxDecoration(
                        color: selected ? AppTheme.accent.withOpacity(0.15) : card,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: selected ? AppTheme.accent.withOpacity(0.5) : border,
                          width: selected ? 1.5 : 1,
                        ),
                      ),
                      child: Column(
                        children: [
                          Icon(t['icon'] as IconData,
                              color: selected ? AppTheme.accent : muted, size: 24),
                          const SizedBox(height: 8),
                          Text(t['label'] as String,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: selected ? AppTheme.accent : muted,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            }).toList(),
          ),

          const SizedBox(height: 28),

          // Версия
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: card,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: border),
            ),
            child: Row(
              children: [
                Icon(Icons.info_outline, color: muted, size: 20),
                const SizedBox(width: 12),
                Text('Версия', style: TextStyle(color: textColor, fontSize: 15)),
                const Spacer(),
                Text('v1.0.0', style: TextStyle(color: muted, fontSize: 14)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
