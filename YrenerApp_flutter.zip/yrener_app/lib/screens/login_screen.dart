import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../theme/app_theme.dart';
import '../services/api_service.dart';
import 'home_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailCtrl = TextEditingController();
  final _keyCtrl = TextEditingController();
  bool _loading = false;
  bool _keyVisible = false;
  String? _error;
  String? _userName;
  bool _keyStep = false; // false = email step, true = key step

  // Простая проверка формата email
  bool _validEmail(String e) =>
      RegExp(r'^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$').hasMatch(e);

  Future<void> _nextStep() async {
    final email = _emailCtrl.text.trim().toLowerCase();
    if (!_validEmail(email)) {
      setState(() => _error = 'Введи корректный email');
      return;
    }
    // Переходим к шагу ключа
    setState(() {
      _error = null;
      _keyStep = true;
      _userName = email.split('@')[0]; // временно имя из email
    });
  }

  Future<void> _confirmAccount(bool yes) async {
    if (!yes) {
      setState(() {
        _keyStep = false;
        _emailCtrl.clear();
        _userName = null;
        _error = null;
      });
      return;
    }
    // Переходим к вводу ключа — уже на шаге ключа
  }

  Future<void> _checkKey() async {
    final key = _keyCtrl.text.trim();
    if (key.isEmpty) {
      setState(() => _error = 'Введи ключ');
      return;
    }
    if (!key.startsWith('Yrener_')) {
      setState(() => _error = 'Неверный формат ключа');
      return;
    }
    setState(() { _loading = true; _error = null; });
    final result = await ApiService.checkKey(key);
    if (!mounted) return;
    setState(() => _loading = false);
    if (result['valid'] == true) {
      await ApiService.saveUser(
        _emailCtrl.text.trim().toLowerCase(),
        _userName ?? 'User',
        key,
      );
      Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (_) => const HomeScreen()));
    } else {
      setState(() => _error = 'Ключ недействителен или истёк');
    }
  }

  void _openSite() => launchUrl(
    Uri.parse('https://yrenercc.netlify.app'),
    mode: LaunchMode.externalApplication,
  );

  void _openBot() => launchUrl(
    Uri.parse('https://t.me/Yrener_Freebot'),
    mode: LaunchMode.externalApplication,
  );

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = isDark ? const Color(0xFF0A0A0A) : const Color(0xFFF5F5F5);
    final card = isDark ? const Color(0xFF111111) : Colors.white;
    final textColor = isDark ? Colors.white : const Color(0xFF1A1A1A);
    final muted = isDark ? const Color(0xFF666666) : const Color(0xFF999999);
    final border = isDark ? Colors.white.withOpacity(0.08) : Colors.black.withOpacity(0.08);

    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            children: [
              const SizedBox(height: 60),
              // Лого
              Container(
                width: 72, height: 72,
                decoration: BoxDecoration(
                  color: AppTheme.accent,
                  borderRadius: BorderRadius.circular(18),
                  boxShadow: [BoxShadow(
                    color: AppTheme.accent.withOpacity(0.35),
                    blurRadius: 24, spreadRadius: 2,
                  )],
                ),
                child: const Center(
                  child: Text('Y', style: TextStyle(
                    fontSize: 36, fontWeight: FontWeight.w900, color: Colors.white,
                  )),
                ),
              ),
              const SizedBox(height: 16),
              Text('Yrener', style: TextStyle(
                fontSize: 30, fontWeight: FontWeight.w800, color: textColor,
              )),
              const SizedBox(height: 6),
              Text(_keyStep ? 'Введи ключ доступа' : 'Войди в аккаунт',
                style: TextStyle(fontSize: 14, color: muted)),
              const SizedBox(height: 36),

              // Карточка
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: card,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: border),
                  boxShadow: [BoxShadow(
                    color: Colors.black.withOpacity(0.15),
                    blurRadius: 20,
                  )],
                ),
                child: !_keyStep ? _buildEmailStep(textColor, muted, border)
                    : _buildKeyStep(textColor, muted, border),
              ),

              const SizedBox(height: 20),

              // Нет аккаунта
              if (!_keyStep) ...[
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('Нет аккаунта? ', style: TextStyle(color: muted, fontSize: 14)),
                    GestureDetector(
                      onTap: _openSite,
                      child: const Text('Зарегистрироваться',
                        style: TextStyle(color: AppTheme.accent, fontSize: 14,
                            fontWeight: FontWeight.w600)),
                    ),
                  ],
                ),
              ],

              const SizedBox(height: 40),

              // Кнопка канала
              _tgBanner(),
              const SizedBox(height: 30),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEmailStep(Color textColor, Color muted, Color border) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _label('Email', textColor),
        const SizedBox(height: 8),
        _input(
          controller: _emailCtrl,
          hint: 'your@example.com',
          keyboard: TextInputType.emailAddress,
          border: border,
          textColor: textColor,
        ),
        if (_error != null) ...[
          const SizedBox(height: 8),
          Text(_error!, style: const TextStyle(color: AppTheme.accent2, fontSize: 13)),
        ],
        const SizedBox(height: 20),
        _primaryBtn('Войти', _nextStep),
      ],
    );
  }

  Widget _buildKeyStep(Color textColor, Color muted, Color border) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Подтверждение аккаунта
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppTheme.accent.withOpacity(0.08),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppTheme.accent.withOpacity(0.2)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Ваш аккаунт?', style: TextStyle(
                fontWeight: FontWeight.w700, color: textColor, fontSize: 15)),
              const SizedBox(height: 4),
              Text(_emailCtrl.text.trim(), style: TextStyle(color: muted, fontSize: 13)),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(child: _outlineBtn('Да, мой', () => _confirmAccount(true))),
                  const SizedBox(width: 10),
                  Expanded(child: _outlineBtn('Нет', () => _confirmAccount(false))),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),

        _label('Ключ доступа', textColor),
        const SizedBox(height: 8),
        Stack(
          children: [
            _input(
              controller: _keyCtrl,
              hint: 'Yrener_XXXX#XXXX#XXXX',
              border: border,
              textColor: textColor,
              obscure: !_keyVisible,
            ),
            Positioned(
              right: 12, top: 14,
              child: GestureDetector(
                onTap: () => setState(() => _keyVisible = !_keyVisible),
                child: Icon(_keyVisible ? Icons.visibility_off : Icons.visibility,
                    color: muted, size: 20),
              ),
            ),
          ],
        ),

        if (_error != null) ...[
          const SizedBox(height: 8),
          Text(_error!, style: const TextStyle(color: AppTheme.accent2, fontSize: 13)),
        ],

        const SizedBox(height: 12),
        // Получить ключ
        GestureDetector(
          onTap: _openBot,
          child: Row(
            children: [
              const Icon(Icons.send, color: Color(0xFF2AABEE), size: 16),
              const SizedBox(width: 6),
              const Text('Получить ключ в боте',
                style: TextStyle(color: Color(0xFF2AABEE), fontSize: 13,
                    fontWeight: FontWeight.w500)),
            ],
          ),
        ),
        const SizedBox(height: 20),
        _loading
            ? const Center(child: CircularProgressIndicator(color: AppTheme.accent))
            : _primaryBtn('Войти', _checkKey),
      ],
    );
  }

  Widget _label(String text, Color color) => Text(text,
    style: TextStyle(fontSize: 13, color: color.withOpacity(0.6), fontWeight: FontWeight.w500));

  Widget _input({
    required TextEditingController controller,
    required String hint,
    required Color border,
    required Color textColor,
    TextInputType keyboard = TextInputType.text,
    bool obscure = false,
  }) =>
    TextField(
      controller: controller,
      keyboardType: keyboard,
      obscureText: obscure,
      style: TextStyle(color: textColor, fontSize: 15),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: TextStyle(color: textColor.withOpacity(0.3), fontSize: 15),
        filled: true,
        fillColor: Colors.black.withOpacity(0.05),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppTheme.accent, width: 1.5),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
    );

  Widget _primaryBtn(String text, VoidCallback onTap) => SizedBox(
    width: double.infinity,
    child: ElevatedButton(
      onPressed: onTap,
      style: ElevatedButton.styleFrom(
        backgroundColor: AppTheme.accent,
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(vertical: 16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        elevation: 0,
      ),
      child: Text(text, style: const TextStyle(
          fontSize: 16, fontWeight: FontWeight.w700)),
    ),
  );

  Widget _outlineBtn(String text, VoidCallback onTap) => OutlinedButton(
    onPressed: onTap,
    style: OutlinedButton.styleFrom(
      foregroundColor: Colors.white,
      side: BorderSide(color: AppTheme.accent.withOpacity(0.4)),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      padding: const EdgeInsets.symmetric(vertical: 10),
    ),
    child: Text(text, style: const TextStyle(fontSize: 14)),
  );

  Widget _tgBanner() => GestureDetector(
    onTap: () => launchUrl(Uri.parse('https://t.me/Yrener_Soft'),
        mode: LaunchMode.externalApplication),
    child: Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF1A2A3A), Color(0xFF1E3A5F)],
        ),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFF2AABEE).withOpacity(0.2)),
      ),
      child: Row(
        children: [
          Container(
            width: 44, height: 44,
            decoration: BoxDecoration(
              color: const Color(0xFF2AABEE),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Center(child: Text('✈', style: TextStyle(fontSize: 22))),
          ),
          const SizedBox(width: 14),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('@YRENER_SOFT', style: TextStyle(
                    fontWeight: FontWeight.w700, color: Colors.white, fontSize: 15)),
                SizedBox(height: 2),
                Text('Новости, обновления, поддержка',
                    style: TextStyle(color: Colors.white54, fontSize: 12)),
              ],
            ),
          ),
          const Text('›', style: TextStyle(color: Colors.white30, fontSize: 24)),
        ],
      ),
    ),
  );
}
