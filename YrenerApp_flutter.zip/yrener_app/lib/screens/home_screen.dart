import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../theme/app_theme.dart';
import '../services/api_service.dart';
import '../main.dart';
import 'login_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  String _userName = '';
  String _userEmail = '';

  // DVD анимация
  late AnimationController _dvdCtrl;
  double _dvdX = 100, _dvdY = 200;
  double _dvdVx = 1.5, _dvdVy = 1.2;
  Timer? _dvdTimer;
  Color _dvdColor = AppTheme.accent;

  // Пульс кнопки
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseScale;

  @override
  void initState() {
    super.initState();
    _loadUser();

    // DVD движение
    _dvdCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 1));
    _dvdTimer = Timer.periodic(const Duration(milliseconds: 16), _moveDvd);

    // Пульс
    _pulseCtrl = AnimationController(vsync: this,
        duration: const Duration(milliseconds: 900))..repeat(reverse: true);
    _pulseScale = Tween(begin: 1.0, end: 1.06).animate(
        CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
  }

  Future<void> _loadUser() async {
    final user = await ApiService.getSavedUser();
    setState(() {
      _userName = user['name'] ?? 'User';
      _userEmail = user['email'] ?? '';
    });
  }

  void _moveDvd(Timer t) {
    if (!mounted) return;
    setState(() {
      _dvdX += _dvdVx;
      _dvdY += _dvdVy;
      final sw = MediaQuery.of(context).size.width - 120;
      final sh = MediaQuery.of(context).size.height - 120;
      if (_dvdX <= 0 || _dvdX >= sw) {
        _dvdVx = -_dvdVx;
        _dvdColor = _randomColor();
      }
      if (_dvdY <= 0 || _dvdY >= sh) {
        _dvdVy = -_dvdVy;
        _dvdColor = _randomColor();
      }
    });
  }

  Color _randomColor() {
    final colors = [
      AppTheme.accent, const Color(0xFF2AABEE), const Color(0xFF32C864),
      const Color(0xFFFF8C00), const Color(0xFFAA44FF),
    ];
    return colors[Random().nextInt(colors.length)];
  }

  void _launchPubg() async {
    const pubgPackage = 'com.tencent.ig';
    final uri = Uri.parse('android-app://$pubgPackage');
    if (!await launchUrl(uri)) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('PUBG Mobile не найден'),
              backgroundColor: AppTheme.accent),
        );
      }
    }
  }

  Future<void> _logout() async {
    await ApiService.clearUser();
    if (mounted) {
      Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (_) => const LoginScreen()));
    }
  }

  @override
  void dispose() {
    _dvdTimer?.cancel();
    _dvdCtrl.dispose();
    _pulseCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = Theme.of(context).scaffoldBackgroundColor;
    final textColor = isDark ? Colors.white : const Color(0xFF1A1A1A);
    final muted = isDark ? const Color(0xFF666666) : const Color(0xFF999999);

    return Scaffold(
      backgroundColor: bg,
      body: Stack(
        children: [
          // DVD текст @YRENER_SOFT
          Positioned(
            left: _dvdX,
            top: _dvdY,
            child: Opacity(
              opacity: 0.12,
              child: Text('@YRENER_SOFT',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  color: _dvdColor,
                  letterSpacing: 2,
                ),
              ),
            ),
          ),

          // Основной контент
          SafeArea(
            child: Column(
              children: [
                // Верхняя панель
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                  child: Row(
                    children: [
                      Container(
                        width: 42, height: 42,
                        decoration: BoxDecoration(
                          color: AppTheme.accent,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Center(
                          child: Text(
                            _userName.isNotEmpty ? _userName[0].toUpperCase() : 'Y',
                            style: const TextStyle(
                              fontSize: 20, fontWeight: FontWeight.w900,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(_userName, style: TextStyle(
                            fontWeight: FontWeight.w700, color: textColor, fontSize: 16)),
                          Text(_userEmail, style: TextStyle(color: muted, fontSize: 12)),
                        ],
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () => Navigator.push(context,
                            MaterialPageRoute(builder: (_) => const SettingsScreen())),
                        icon: Icon(Icons.settings_outlined, color: muted),
                      ),
                      IconButton(
                        onPressed: _logout,
                        icon: Icon(Icons.logout, color: muted),
                      ),
                    ],
                  ),
                ),

                // Центральная зона
                Expanded(
                  child: Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // Лого Y
                        Container(
                          width: 100, height: 100,
                          decoration: BoxDecoration(
                            color: AppTheme.accent,
                            borderRadius: BorderRadius.circular(26),
                            boxShadow: [BoxShadow(
                              color: AppTheme.accent.withOpacity(0.4),
                              blurRadius: 40, spreadRadius: 5,
                            )],
                          ),
                          child: const Center(
                            child: Text('Y', style: TextStyle(
                              fontSize: 52, fontWeight: FontWeight.w900,
                              color: Colors.white,
                            )),
                          ),
                        ),
                        const SizedBox(height: 20),
                        Text('YRENER MENU', style: TextStyle(
                          fontSize: 22, fontWeight: FontWeight.w800,
                          color: textColor, letterSpacing: 3,
                        )),
                        const SizedBox(height: 6),
                        Text('PUBG Mobile', style: TextStyle(
                          fontSize: 13, color: muted, letterSpacing: 1)),
                        const SizedBox(height: 50),

                        // Кнопка "Начать играть" с пульсом
                        ScaleTransition(
                          scale: _pulseScale,
                          child: GestureDetector(
                            onTap: _launchPubg,
                            child: Container(
                              width: 200, height: 60,
                              decoration: BoxDecoration(
                                gradient: const LinearGradient(
                                  colors: [AppTheme.accent, AppTheme.accent2],
                                ),
                                borderRadius: BorderRadius.circular(30),
                                boxShadow: [
                                  BoxShadow(
                                    color: AppTheme.accent.withOpacity(0.5),
                                    blurRadius: 20, spreadRadius: 2,
                                  ),
                                ],
                              ),
                              child: const Center(
                                child: Text('Начать играть',
                                  style: TextStyle(
                                    fontSize: 17, fontWeight: FontWeight.w800,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                // Нижняя панель
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
                  child: Row(
                    children: [
                      Expanded(child: _bottomBtn(
                        '📢 @Yrener_Soft',
                        () => launchUrl(Uri.parse('https://t.me/Yrener_Soft'),
                            mode: LaunchMode.externalApplication),
                      )),
                      const SizedBox(width: 12),
                      Expanded(child: _bottomBtn(
                        '💬 Поддержка',
                        () => launchUrl(Uri.parse('https://t.me/Yrener_Freebot'),
                            mode: LaunchMode.externalApplication),
                      )),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _bottomBtn(String text, VoidCallback onTap) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.07)),
      ),
      child: Center(
        child: Text(text, style: const TextStyle(
          fontSize: 13, fontWeight: FontWeight.w600, color: Colors.white70)),
      ),
    ),
  );
}
